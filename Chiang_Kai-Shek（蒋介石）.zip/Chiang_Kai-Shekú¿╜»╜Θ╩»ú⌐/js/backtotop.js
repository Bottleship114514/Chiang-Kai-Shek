var goTop = document.querySelector('.goTop')
// 平滑回到页面最顶部
goTop.addEventListener('click', function () {
  window.scrollTo({ top: 0, left: 0, behavior: "smooth" });
})